RutaCamión V6 — OpenStreetMap

Esta versión ya no necesita Google Maps, API Key ni una cuenta de facturación.

Incluye:
- Aplicación Android nativa.
- Apariencia azul y textos blancos.
- Mapa real de OpenStreetMap.
- Ubicación GPS del teléfono.
- Seguimiento durante la navegación.
- Servicio de ubicación en primer plano.
- Notificación permanente.
- Alertas por peso y altura.
- Restricciones piloto en Tacuarembó.

Cómo probar:
1. Descomprimir el archivo.
2. Abrir la carpeta en Android Studio.
3. Esperar la sincronización de Gradle.
4. Conectar el teléfono con depuración USB.
5. Pulsar Run.

Limitaciones actuales:
- Los marcadores de restricciones son datos de prueba.
- La app todavía no calcula una ruta alternativa.
- Los mosaicos públicos de OpenStreetMap requieren internet y deben utilizarse respetando su política de uso.
- osmdroid sirve para este prototipo, pero el proyecto está archivado; para una versión comercial se recomienda migrar a una biblioteca mantenida.
