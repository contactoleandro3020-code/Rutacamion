package com.rutacamion.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.*

class NavigationService : Service() {

    companion object {
        const val CHANNEL_NAV = "navigation"
        const val CHANNEL_ALERTS = "alerts"
        const val NAV_ID = 1001
    }

    private lateinit var locationClient: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val alerted = mutableSetOf<String>()
    private var truckWeight = 28000
    private var truckHeight = 4.10

    override fun onCreate() {
        super.onCreate()
        createChannels()
        locationClient = LocationServices.getFusedLocationProviderClient(this)

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let {
                    updateNavigationNotification(it)
                    checkRestrictions(it)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        truckWeight = intent?.getIntExtra("truck_weight_kg", 28000) ?: 28000
        truckHeight = intent?.getDoubleExtra("truck_height_m", 4.10) ?: 4.10

        ServiceCompat.startForeground(
            this,
            NAV_ID,
            navigationNotification("GPS activo"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        )
        startLocationUpdates()
        return START_STICKY
    }

    @Suppress("MissingPermission")
    private fun startLocationUpdates() {
        if (
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return
        }

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            5000L
        ).setMinUpdateDistanceMeters(20f).build()

        locationClient.requestLocationUpdates(request, callback, mainLooper)
    }

    private fun checkRestrictions(location: Location) {
        RestrictionRepository.restrictions.forEach { restriction ->
            val result = FloatArray(1)
            Location.distanceBetween(
                location.latitude,
                location.longitude,
                restriction.latitude,
                restriction.longitude,
                result
            )

            val incompatible =
                (restriction.maxWeightKg != null && truckWeight > restriction.maxWeightKg) ||
                (restriction.maxHeightM != null && truckHeight > restriction.maxHeightM)

            if (incompatible && result[0] <= restriction.radiusMeters && alerted.add(restriction.id)) {
                showAlert(restriction, result[0])
            }

            if (result[0] > restriction.radiusMeters * 2) {
                alerted.remove(restriction.id)
            }
        }
    }

    private fun showAlert(restriction: Restriction, distance: Float) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Restricción para tu camión")
            .setContentText("${restriction.name} a ${distance.toInt()} m · ${restriction.message}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        getSystemService(NotificationManager::class.java)
            .notify(restriction.id.hashCode(), notification)
    }

    private fun updateNavigationNotification(location: Location) {
        getSystemService(NotificationManager::class.java).notify(
            NAV_ID,
            navigationNotification(
                "Ubicación: ${"%.5f".format(location.latitude)}, ${"%.5f".format(location.longitude)}"
            )
        )
    }

    private fun navigationNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_NAV)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("RutaCamión")
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_NAV,
                "Navegación",
                NotificationManager.IMPORTANCE_LOW
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERTS,
                "Alertas de restricciones",
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    override fun onDestroy() {
        locationClient.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
