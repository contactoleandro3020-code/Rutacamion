package com.rutacamion.app

data class Restriction(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Float,
    val maxWeightKg: Int? = null,
    val maxHeightM: Double? = null,
    val message: String
)

object RestrictionRepository {
    val restrictions = listOf(
        Restriction(
            "pilot_weight_01",
            "Puente piloto",
            -31.7280,
            -55.9750,
            250f,
            maxWeightKg = 20000,
            message = "Máximo 20 toneladas"
        ),
        Restriction(
            "pilot_height_01",
            "Paso bajo piloto",
            -31.7410,
            -55.9930,
            250f,
            maxHeightM = 4.0,
            message = "Altura máxima 4,00 metros"
        )
    )
}
