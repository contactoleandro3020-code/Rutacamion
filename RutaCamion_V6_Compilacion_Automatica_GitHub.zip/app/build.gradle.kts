plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rutacamion.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rutacamion.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.6"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("org.osmdroid:osmdroid-android:6.1.20")
}
